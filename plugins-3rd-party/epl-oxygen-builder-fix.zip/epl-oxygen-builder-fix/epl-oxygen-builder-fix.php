<?php
/*
Plugin Name: EPL Oxygen Builder Fix
Description: EPL - Oxygen Builder Fix for loading Jquery UI from CDN
Version: 1.0.0
*/

/**
 * unLoads jquery ui front end scripts when oxygen builder is active.
 *
 * @since 1.0
 */
function epl_wp_oxygen_builder_fix() {
	
	if( isset( $_GET['ct_builder'] ) &&  'true' == $_GET['ct_builder'] ) {
		wp_dequeue_script( 'jquery-ui-slider' );
		wp_dequeue_script( 'jquery-touch-punch' );
	}

}
add_action( 'wp_enqueue_scripts', 'epl_wp_oxygen_builder_fix',99 );